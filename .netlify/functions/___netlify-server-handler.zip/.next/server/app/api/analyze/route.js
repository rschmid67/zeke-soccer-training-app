(()=>{var a={};a.id=786,a.ids=[786],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},716:()=>{},846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},2367:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>D,patchFetch:()=>C,routeModule:()=>y,serverHooks:()=>B,workAsyncStorage:()=>z,workUnitAsyncStorage:()=>A});var d={};c.r(d),c.d(d,{POST:()=>x,maxDuration:()=>u});var e=c(5736),f=c(9117),g=c(4044),h=c(9326),i=c(2324),j=c(261),k=c(4290),l=c(5328),m=c(8928),n=c(6595),o=c(3421),p=c(7679),q=c(1681),r=c(3446),s=c(6439),t=c(1356);let u=60,v="https://generativelanguage.googleapis.com";async function w(a,b,c=45e3){let d=Date.now()+c;for(;Date.now()<d;){let c=await fetch(`${v}/v1beta/${a}?key=${b}`),d=await c.json(),e=d.state??d.file?.state;if("ACTIVE"===e)return;if("FAILED"===e)throw Error("Gemini video processing failed");await new Promise(a=>setTimeout(a,2500))}throw Error("Gemini video processing timed out — try a shorter clip")}async function x(a){let b=process.env.GEMINI_API_KEY;if(!b)return Response.json({error:"GEMINI_API_KEY is not configured"},{status:500});if((a.headers.get("content-type")||"").includes("application/json")){let{fileUri:c,fileName:d,mimeType:e,description:f,profile:g,skills:h}=await a.json(),i=Object.entries(h||{}).map(([a,b])=>`${a}: ${b}/100`).join(", ");await w(d,b);let j=`You are an elite youth soccer development coach conducting a video performance review.

PLAYER TO FIND: ${f}
Focus exclusively on this player throughout the entire video. Ignore all other players.

Player profile:
  Name     : ${g.name||"Zeke"}
  Age      : ${g.age||11}
  Position : ${g.position||"Attacking Mid"}
  Goal     : ${g.goal||"Make CONCACAF U15 Cup team in 2029"}
  Current skill scores: ${i}

STEP 1 — VIDEO TYPE: Determine if this is:
• GAME FOOTAGE — a match with multiple players on a full field
• TRAINING FOOTAGE — individual drills, solo practice, or skills work
State which it is at the very start.

STEP 2 — FULL COACHING ANALYSIS:

1. TECHNICAL SKILLS (with timestamps where possible):
   - First touch: quality, direction, setting up next action
   - Passing: accuracy, weight, choice of target
   - Dribbling: close control, change of direction, speed on the ball
   - Shooting: mechanics, placement, decision to shoot

2. MOVEMENT & POSITIONING:
   - Movement off the ball, ability to find pockets of space
   - Body shape when receiving under pressure
   - Timing of runs (game: runs in behind, across, checking in; training: body shape across reps)

3. DECISION MAKING & SOCCER IQ:
   - When to pass vs dribble vs shoot
   - Pressing triggers and defensive work-rate
   - Vision — can the player play forward or see the next pass early?

4. PHYSICAL ATTRIBUTES:
   - Speed with and without the ball (reference yards/mph where possible)
   - Agility and quickness of direction changes
   - Physical presence in duels (game footage)

5. IF GAME FOOTAGE — Performance under pressure:
   - Composure when pressed by opponents
   - Link-up play and combination passing with teammates
   - Moments that created danger or where opportunities were missed

   IF TRAINING FOOTAGE — Technique quality:
   - Consistency of technique across repetitions
   - Training intensity and intentionality
   - Which technical flaws repeat across reps

6. STRENGTHS — 2-3 genuine positives visible in this footage

7. AREAS TO IMPROVE — 2-3 specific weaknesses, each with:
   - A named drill to address it
   - Sets/reps in imperial units

8. CONCACAF U15 2029 READINESS:
   - What does an elite ${g.age||11}-year-old Attacking Mid targeting U15 national selection look like?
   - What specific gaps exist between this player and that standard?
   - The single most important thing to improve right now

Quote specific timestamps for key moments. Be honest, technical, and direct. Use imperial units throughout.`,k=await fetch(`${v}/v1beta/models/gemini-1.5-pro:generateContent?key=${b}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{fileData:{mimeType:e||"video/mp4",fileUri:c}},{text:j}]}],generationConfig:{maxOutputTokens:2048,temperature:.4}})});if(!k.ok){let a=await k.text();throw Error(`Gemini analysis failed (${k.status}): ${a}`)}let l=await k.json();console.log("[analyze] JSON body flow — Gemini raw response:",JSON.stringify(l).slice(0,500));let m=l.candidates?.[0]?.content?.parts?.[0]?.text;if(!m){let a=l.candidates?.[0]?.finishReason,b=l.error?.message||(a&&"STOP"!==a?`Finish reason: ${a}`:null)||l.promptFeedback?.blockReason||JSON.stringify(l).slice(0,300);return Response.json({error:`Gemini returned no analysis text: ${b}`},{status:500})}return fetch(`${v}/v1beta/${d}?key=${b}`,{method:"DELETE"}).catch(()=>{}),Response.json({text:m})}let c=await a.formData(),d=c.get("video"),e=JSON.parse(c.get("profile")||"{}"),f=JSON.parse(c.get("skills")||"{}"),g=JSON.parse(c.get("frames")||"[]"),h=c.get("description")||"",i=Object.entries(f).map(([a,b])=>`${a}: ${b}/100`).join(", ");if(!d&&g.length>0){let a=h?`PLAYER TO FIND: ${h}
Focus exclusively on this player in every frame. Ignore all other players.`:"Focus on player #13 wearing a white jersey and blue cleats.",c=`You are an elite youth soccer development coach analyzing ${g.length} frames extracted from a soccer video.

${a}

Player profile:
  Name     : ${e.name||"Zeke"}
  Age      : ${e.age||11}
  Position : ${e.position||"Attacking Mid"}
  Goal     : ${e.goal||"Make CONCACAF U15 Cup team in 2029"}
  Current skill scores: ${i}

STEP 1 — VIDEO TYPE: From the frames, determine if this is:
• GAME FOOTAGE — a match with multiple players on a full field
• TRAINING FOOTAGE — individual drills, solo practice, or skills work
State which at the start.

STEP 2 — COACHING ANALYSIS (base everything on what you can actually observe):

1. TECHNICAL SKILLS:
   - First touch: quality, body shape, direction it sets up
   - Passing: accuracy, weight, choice of target
   - Dribbling: close control, ability to change direction under pressure
   - Shooting: mechanics, body shape, placement (if visible)

2. MOVEMENT & POSITIONING:
   - Movement off the ball, ability to find space
   - Body shape when receiving — can the player play forward?
   - Timing and quality of runs (game: runs in behind or across; training: repetition quality)

3. DECISION MAKING & SOCCER IQ:
   - Pass vs dribble vs shoot choices
   - Defensive pressure awareness and pressing work-rate
   - Vision — does the player look before receiving?

4. PHYSICAL ATTRIBUTES:
   - Speed with and without the ball
   - Agility, quickness of direction change
   - Physical presence in challenges (game footage)

5. IF GAME FOOTAGE — Under-pressure performance:
   - Composure when closed down
   - Link-up play with teammates
   - Moments that created or wasted chances

   IF TRAINING FOOTAGE — Technique quality:
   - Consistency across repetitions
   - Training intensity and focus
   - Recurring technical flaws

6. STRENGTHS — 2-3 genuine positives visible in these frames

7. AREAS TO IMPROVE — 2-3 specific weaknesses, each with:
   - A named drill to fix it
   - Sets/reps in imperial units

8. CONCACAF U15 2029 READINESS:
   - What does an elite ${e.age||11}-year-old Attacking Mid targeting U15 national selection look like?
   - What are the specific gaps between this player and that standard?
   - The single most important thing to improve right now

Be honest, direct, and technical. Use imperial units throughout.`,d=g.map(a=>({inlineData:{mimeType:"image/jpeg",data:a}})),f=await fetch(`${v}/v1beta/models/gemini-1.5-pro:generateContent?key=${b}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[...d,{text:c}]}],generationConfig:{maxOutputTokens:2048,temperature:.4}})}),j=await f.json();console.log("[analyze] Frames flow — Gemini raw response:",JSON.stringify(j).slice(0,500));let k=j.candidates?.[0]?.content?.parts?.[0]?.text;if(!k){let a=j.candidates?.[0]?.finishReason,b=j.error?.message||(a&&"STOP"!==a?`Finish reason: ${a}`:null)||j.promptFeedback?.blockReason||JSON.stringify(j).slice(0,300);return Response.json({error:`Gemini returned no analysis text: ${b}`},{status:500})}return Response.json({text:k})}let j=`You are an expert youth soccer coach reviewing training footage of player #13 wearing a white jersey and blue cleats.

Player profile:
  Name     : ${e.name}
  Age      : ${e.age}
  Position : ${e.position}
  Goal     : ${e.goal}
  Current skill scores: ${i}

Provide specific coaching feedback:

1. TECHNIQUE OBSERVATIONS — Footwork, first touch, ball control, shooting mechanics, passing technique.
2. POSITIONING & MOVEMENT — How #13 finds space, times runs, and shapes as an attacking mid off the ball.
3. DECISION MAKING — Quality of decisions in possession and pressing moments.
4. STRENGTHS — 2-3 genuine positives you can see in this footage.
5. AREAS TO IMPROVE — 2-3 specific weaknesses, each with a named drill to address it.
6. SKILL SCORE ADJUSTMENTS — Suggest a +/- adjustment for: dribbling, shooting, passing, speed, agility, positioning.
7. NEXT SESSION PRIORITY — The single most important drill, with sets/reps in imperial units.

Be technical and specific to what you actually observe. Reference what elite attacking mids do at age ${e.age}. Use imperial units throughout.`;if(!d){let a=`You are an expert soccer coach. Provide detailed position-specific coaching feedback for:

Player: ${e.name}, Age: ${e.age}, Position: ${e.position}
Goal: ${e.goal}
Current skill scores: ${i}

Give:
1. TECHNIQUE FOCUS (3-4 key areas for a ${e.position} at age ${e.age})
2. STRENGTHS TO BUILD ON
3. AREAS TO IMPROVE (with a specific drill for each)
4. SKILL SCORE ADJUSTMENTS (suggest +/- based on the profile)
5. NEXT SESSION PRIORITY (1 drill, reps/sets, imperial units)

Be direct and technical. Use imperial units throughout.`,c=await fetch(`${v}/v1beta/models/gemini-1.5-pro:generateContent?key=${b}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:a}]}]})}),d=await c.json(),f=d.candidates?.[0]?.content?.parts?.[0]?.text;if(!f){let a=d.error?.message||d.promptFeedback?.blockReason||JSON.stringify(d);throw Error(`Gemini returned no analysis: ${a}`)}return Response.json({text:f})}let k=Buffer.from(await d.arrayBuffer()),l=d.type||"video/mp4",m=d.name||"training.mp4",n=`GeminiBoundary${Date.now()}`,o=Buffer.from(`--${n}\r
Content-Type: application/json; charset=UTF-8\r
\r
${JSON.stringify({file:{displayName:m}})}\r
--${n}\r
Content-Type: ${l}\r
\r
`),p=Buffer.from(`\r
--${n}--`),q=Buffer.concat([o,k,p]),r=await fetch(`${v}/upload/v1beta/files?key=${b}`,{method:"POST",headers:{"Content-Type":`multipart/related; boundary=${n}`,"Content-Length":String(q.length)},body:q});if(!r.ok){let a=await r.text();throw Error(`Gemini upload failed (${r.status}): ${a}`)}let s=await r.json(),t=s.file?.uri,u=s.file?.name;if(!t)throw Error("Gemini upload returned no file URI");await w(u,b);let x=await fetch(`${v}/v1beta/models/gemini-1.5-pro:generateContent?key=${b}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{fileData:{mimeType:l,fileUri:t}},{text:`Watch the full video. Quote specific timestamps where possible.

${j}`}]}],generationConfig:{maxOutputTokens:2048,temperature:.4}})});if(!x.ok){let a=await x.text();throw Error(`Gemini analysis failed (${x.status}): ${a}`)}let y=await x.json();console.log("[analyze] FormData video flow — Gemini raw response:",JSON.stringify(y).slice(0,500));let z=y.candidates?.[0]?.content?.parts?.[0]?.text;if(!z){let a=y.candidates?.[0]?.finishReason,b=y.error?.message||(a&&"STOP"!==a?`Finish reason: ${a}`:null)||y.promptFeedback?.blockReason||JSON.stringify(y).slice(0,300);throw Error(`Gemini returned no analysis text: ${b}`)}return fetch(`${v}/v1beta/${u}?key=${b}`,{method:"DELETE"}).catch(()=>{}),Response.json({text:z})}let y=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/analyze/route",pathname:"/api/analyze",filename:"route",bundlePath:"app/api/analyze/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"C:\\Users\\rschm\\OneDrive\\Projects\\Zeke Soccer Training App\\app\\api\\analyze\\route.js",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:z,workUnitAsyncStorage:A,serverHooks:B}=y;function C(){return(0,g.patchFetch)({workAsyncStorage:z,workUnitAsyncStorage:A})}async function D(a,b,c){var d;let e="/api/analyze/route";"/index"===e&&(e="/");let g=await y.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:z,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(z.dynamicRoutes[E]||z.routes[D]);if(F&&!x){let a=!!z.routes[D],b=z.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||y.isDev||x||(G="/index"===(G=D)?"/":G);let H=!0===y.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:z,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>y.onRequestError(a,b,d,A)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>y.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await y.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},A),b}},l=await y.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await y.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},3033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3421:(a,b,c)=>{"use strict";Object.defineProperty(b,"I",{enumerable:!0,get:function(){return g}});let d=c(1237),e=c(5088),f=c(7679);async function g(a,b,c,g){if((0,d.isNodeNextResponse)(b)){var h;b.statusCode=c.status,b.statusMessage=c.statusText;let d=["set-cookie","www-authenticate","proxy-authenticate","vary"];null==(h=c.headers)||h.forEach((a,c)=>{if("x-middleware-set-cookie"!==c.toLowerCase())if("set-cookie"===c.toLowerCase())for(let d of(0,f.splitCookiesString)(a))b.appendHeader(c,d);else{let e=void 0!==b.getHeader(c);(d.includes(c.toLowerCase())||!e)&&b.appendHeader(c,a)}});let{originalResponse:i}=b;c.body&&"HEAD"!==a.method?await (0,e.pipeToNodeResponse)(c.body,i,g):i.end()}}},4870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},5736:(a,b,c)=>{"use strict";a.exports=c(4870)},6439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},6487:()=>{},9294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[873],()=>b(b.s=2367));module.exports=c})();