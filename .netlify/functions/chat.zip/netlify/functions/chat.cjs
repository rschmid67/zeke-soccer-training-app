var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/chat.js
var chat_exports = {};
__export(chat_exports, {
  config: () => config,
  default: () => chat_default
});
module.exports = __toCommonJS(chat_exports);
var import_sdk = __toESM(require("@anthropic-ai/sdk"));
var client = new import_sdk.default({ apiKey: process.env.ANTHROPIC_API_KEY });
function extractDrills(text) {
  const drills = [];
  const seen = /* @__PURE__ */ new Set();
  const add = (raw) => {
    const name = raw.trim().replace(/^[^A-Za-z]+/, "").trim();
    if (name.length >= 4 && name.length <= 50 && !seen.has(name)) {
      seen.add(name);
      drills.push(name);
    }
  };
  for (const m of text.matchAll(/^##\s+\d+\.\s*(.+)/gm)) add(m[1]);
  if (drills.length >= 3) return drills.slice(0, 3);
  const skip = /^(beginner|intermediate|advanced|tips|setup|note|important|drill|level)/i;
  for (const m of text.matchAll(/^##\s+([^#\n]{4,50})/gm)) {
    if (!skip.test(m[1].trim())) add(m[1]);
  }
  if (drills.length >= 3) return drills.slice(0, 3);
  for (const m of text.matchAll(/^[-*]\s+\*\*([^*\n]{3,50})\*\*/gm)) add(m[1]);
  if (drills.length >= 3) return drills.slice(0, 3);
  for (const m of text.matchAll(/\*\*\d+[.)]\s*([A-Za-z][^*\n]{2,45})\*\*/g)) add(m[1]);
  if (drills.length >= 3) return drills.slice(0, 3);
  for (const m of text.matchAll(/\*\*([A-Z][A-Za-z0-9 &'/\-]{3,45})\*\*\s*[:–-]/g)) add(m[1]);
  return drills.slice(0, 3);
}
var chat_default = async (request) => {
  if (request.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }
  try {
    const { system, messages } = await request.json();
    const firstUserIdx = messages.findIndex((m) => m.role === "user");
    const trimmed = messages.slice(firstUserIdx);
    const hasImages = trimmed.some(
      (m) => Array.isArray(m.content) && m.content.some((b) => b.type === "image")
    );
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: hasImages ? 2048 : 1024,
      system,
      messages: trimmed
    });
    const text = response.content[0]?.text ?? "Let's keep grinding \u2014 you've got this!";
    const drillNames = extractDrills(text);
    const videos = drillNames.map((name) => ({
      name,
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(name + " youth soccer tutorial")}`
    }));
    return Response.json({ text, videos });
  } catch (err) {
    console.error("Chat function error:", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
};
var config = { path: "/api/chat" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
