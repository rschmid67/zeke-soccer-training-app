var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/db.js
var db_exports = {};
__export(db_exports, {
  config: () => config,
  default: () => db_default
});
module.exports = __toCommonJS(db_exports);
var import_serverless = require("@neondatabase/serverless");
var sql = (0, import_serverless.neon)(process.env.DATABASE_URL);
async function initSchema() {
  await sql`
    CREATE TABLE IF NOT EXISTS profiles (
      user_id TEXT PRIMARY KEY,
      name TEXT,
      age INTEGER,
      position TEXT,
      height TEXT,
      weight TEXT,
      goal TEXT,
      target_year INTEGER,
      idols TEXT[],
      club TEXT,
      coach_email TEXT,
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS skills (
      user_id TEXT PRIMARY KEY,
      dribbling INTEGER DEFAULT 0,
      shooting  INTEGER DEFAULT 0,
      passing   INTEGER DEFAULT 0,
      speed     INTEGER DEFAULT 0,
      agility   INTEGER DEFAULT 0,
      defending INTEGER DEFAULT 0,
      heading   INTEGER DEFAULT 0,
      positioning INTEGER DEFAULT 0,
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS sessions (
      id SERIAL PRIMARY KEY,
      user_id TEXT,
      date DATE,
      type TEXT,
      duration INTEGER,
      source TEXT,
      notes TEXT,
      score INTEGER,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `;
}
async function handleGet(params) {
  const userId = params.get("userId") || "default";
  const action = params.get("action");
  if (action === "init") {
    await initSchema();
    return { ok: true };
  }
  const [profileRows, skillRows, sessionRows] = await Promise.all([
    sql`SELECT * FROM profiles WHERE user_id = ${userId}`,
    sql`SELECT * FROM skills   WHERE user_id = ${userId}`,
    sql`SELECT * FROM sessions WHERE user_id = ${userId} ORDER BY date DESC`
  ]);
  return {
    profile: profileRows[0] || null,
    skills: skillRows[0] || null,
    sessions: sessionRows
  };
}
async function handlePost(body) {
  const { action, userId = "default", data } = body;
  if (action === "saveProfile") {
    await sql`
      INSERT INTO profiles (user_id, name, age, position, height, weight, goal, target_year, idols, club, coach_email, updated_at)
      VALUES (${userId}, ${data.name}, ${data.age}, ${data.position}, ${data.height}, ${data.weight},
              ${data.goal}, ${data.targetYear}, ${data.idols}, ${data.club}, ${data.coachEmail}, NOW())
      ON CONFLICT (user_id) DO UPDATE SET
        name = EXCLUDED.name, age = EXCLUDED.age, position = EXCLUDED.position,
        height = EXCLUDED.height, weight = EXCLUDED.weight, goal = EXCLUDED.goal,
        target_year = EXCLUDED.target_year, idols = EXCLUDED.idols,
        club = EXCLUDED.club, coach_email = EXCLUDED.coach_email, updated_at = NOW()
    `;
    return { ok: true };
  }
  if (action === "saveSkills") {
    await sql`
      INSERT INTO skills (user_id, dribbling, shooting, passing, speed, agility, defending, heading, positioning, updated_at)
      VALUES (${userId}, ${data.dribbling}, ${data.shooting}, ${data.passing}, ${data.speed},
              ${data.agility}, ${data.defending}, ${data.heading}, ${data.positioning}, NOW())
      ON CONFLICT (user_id) DO UPDATE SET
        dribbling = EXCLUDED.dribbling, shooting = EXCLUDED.shooting, passing = EXCLUDED.passing,
        speed = EXCLUDED.speed, agility = EXCLUDED.agility, defending = EXCLUDED.defending,
        heading = EXCLUDED.heading, positioning = EXCLUDED.positioning, updated_at = NOW()
    `;
    return { ok: true };
  }
  if (action === "addSession") {
    const [row] = await sql`
      INSERT INTO sessions (user_id, date, type, duration, source, notes, score)
      VALUES (${userId}, ${data.date}, ${data.type}, ${data.duration}, ${data.source}, ${data.notes}, ${data.score})
      RETURNING *
    `;
    return { ok: true, session: row };
  }
  if (action === "deleteSession") {
    await sql`DELETE FROM sessions WHERE id = ${data.id} AND user_id = ${userId}`;
    return { ok: true };
  }
  if (action === "resetAll") {
    await Promise.all([
      sql`DELETE FROM sessions WHERE user_id = ${userId}`,
      sql`UPDATE skills SET dribbling=0, shooting=0, passing=0, speed=0, agility=0, defending=0, heading=0, positioning=0, updated_at=NOW() WHERE user_id = ${userId}`,
      sql`UPDATE profiles SET name=${data.name || ""}, age=${data.age || null}, position=${data.position || ""}, goal=${data.goal || ""}, target_year=${data.targetYear || null}, height='', weight='', idols='{}', club='', coach_email='', updated_at=NOW() WHERE user_id = ${userId}`
    ]);
    return { ok: true };
  }
  return { error: "Unknown action" };
}
var db_default = async (request) => {
  try {
    if (request.method === "GET") {
      const { searchParams } = new URL(request.url);
      const result = await handleGet(searchParams);
      return Response.json(result);
    }
    if (request.method === "POST") {
      const body = await request.json();
      const result = await handlePost(body);
      return Response.json(result);
    }
    return new Response("Method Not Allowed", { status: 405 });
  } catch (err) {
    console.error("DB function error:", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
};
var config = { path: "/api/db" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
